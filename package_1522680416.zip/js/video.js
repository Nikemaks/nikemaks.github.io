/* Проигрывание видео по нажатию на него*/
const video = document.querySelector('video');
video.onclick = () => video.paused ? video.play() : video.pause();

/* кнопка проигрывания*/